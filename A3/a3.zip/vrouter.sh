#!/bin/bash

#Run script for the sender distributed as a part of 
#Assignment 3
#Computer Networks (CS 456)
#
#Number of parameters: 3
#Parameter:
#    $1: <nfe-ip>
#	 $2: <nfe-port>
#    $3: <virtual-router-id>

python3 vrouter.py $1 $2 $3


