#!/bin/bash

#Run script for the sender distributed as a part of 
#Assignment 3
#Computer Networks (CS 456)
#
#Number of parameters: 3
#Parameter:
#    $1: <IP>
#	 $2: <port>
#    $3: <topo_filepath>

python3 nfe.py $1 $2 $3


