import sys
import threading
from socket import *
import heapq
import struct

filename = "topology_n.out"
filename2 = "routingtable_n.out"

nfe_ip = ""
nfe_port = ""
router_id = 0

#a vertex class to represent a router 
class Vertex:
    def __init__(self, node):
        self.id = node
        self.adjacent = {}
        # Set distance to infinity for all nodes
        self.distance = float("inf")
        # Mark all nodes unvisited        
        self.visited = False  
        # Predecessor
        self.previous = None

    def add_neighbor(self, neighbor, weight=0):
        self.adjacent[neighbor] = weight

    def get_connections(self):
        return self.adjacent.keys()  

    def get_id(self):
        return self.id

    def get_weight(self, neighbor):
        return self.adjacent[neighbor]

    def set_distance(self, dist):
        self.distance = dist

    def get_distance(self):
        return self.distance

    def set_previous(self, prev):
        self.previous = prev

    def set_visited(self):
        self.visited = True
        
    def set_unvisited(self):
        self.visited = False
    
    def __str__(self):
        return str(self.id) + ' adjacent: ' + str([x.id for x in self.adjacent])

    def __lt__(self, other): 
        if(self.get_distance()<other.get_distance()):
            return True            
        else:
            return False
        
#a graph class to represent the entire network
#with links
class Graph:
    def __init__(self):
        self.vert_dict = {}
        self.num_vertices = 0

    def __iter__(self):
        return iter(self.vert_dict.values())

    def add_vertex(self, node):
        self.num_vertices = self.num_vertices + 1
        new_vertex = Vertex(node)
        self.vert_dict[node] = new_vertex
        return new_vertex

    def get_vertex(self, n):
        if n in self.vert_dict:
            return self.vert_dict[n]
        else:
            return None

    def add_edge(self, frm, to, cost = 0):
        if frm not in self.vert_dict:
            self.add_vertex(frm)
        if to not in self.vert_dict:
            self.add_vertex(to)

        self.vert_dict[frm].add_neighbor(self.vert_dict[to], cost)
        self.vert_dict[to].add_neighbor(self.vert_dict[frm], cost)
        #print("edge added:{},{},{},".format(frm,to,cost))

    def get_vertices(self):
        return self.vert_dict.keys()

    def set_previous(self, current):
        self.previous = current

    def get_previous(self, current):
        return self.previous

def shortest(v, path):
    ''' make shortest path from v.previous'''
    if v.previous:
        path.append(v.previous.get_id())
        shortest(v.previous, path)
    return



def dijkstra(aGraph, start):
    #reset the graph information 
    for i in aGraph:
        i.set_unvisited()
        i.set_distance(float("inf"))
        i.set_previous(None)
        
    #print '''Dijkstra's shortest path'''
    # Set the distance for the start node to zero 
    start.set_distance(0)

    # Put tuple pair into the priority queue
    unvisited_queue = [(v.get_distance(),v) for v in aGraph]
    heapq.heapify(unvisited_queue)

    while len(unvisited_queue):
        # Pops a vertex with the smallest distance 
        uv = heapq.heappop(unvisited_queue)
        current = uv[1]
        current.set_visited()

        #for next in v.adjacent:
        for n in current.adjacent:
            # if visited, skip
            if n.visited:
                continue
            new_dist = current.get_distance() + current.get_weight(n)
           # print("dist:{} weight:{}".format(current.get_distance(),current.get_weight(n)))
            
            if new_dist < n.get_distance():
                n.set_distance(new_dist)
                n.set_previous(current)
                #print("updated: current = {} next = {} new_dist = {}".format(current.get_id(),n.get_id(),n.get_distance()))
            #else:
               # print ("not updated : current = {} next = {} new_dist = {}".format(current.get_id(), n.get_id(), n.get_distance()))

        # Rebuild heap
        # 1. Pop every item
        while len(unvisited_queue):
            heapq.heappop(unvisited_queue)
        # 2. Put all vertices not visited into the queue
        unvisited_queue = [(v.get_distance(),v) for v in aGraph if not v.visited]
        heapq.heapify(unvisited_queue)


#topology base
class Topology:
    def __init__(self):
        self.topo = []  #topology entry 
        self.ID = [-1]*255 #ID
        self.router1 = [-1]*255 #router1 ID
        self.router2 = [-1]*255 #router2 ID
        self.cost = [-1]*255         
        self.linkIndex = 0        


    #add entry to the topology base 
    def addEntry(self,r1, r2, LID, LC):
        self.topo.append([r1,r2,LID,LC])
        self.ID[LID] = self.linkIndex
        self.router1[LID] = r1
        self.router2[LID] = r2
        self.cost[LID] = LC         
        self.linkIndex += 1
        
    #update the unknown router information to the topology base        
    def updateRouter2(self,LID,r2,g):
        self.router2[LID] = r2
        index = self.findEntryByLID(LID)
        
        (a,b,c,d) = self.topo[index]
        self.topo[index] = (a,r2,c,d)
        
        g.add_edge(a,r2,d)    

    def findEntryByLID(self,LID):
        return self.ID[LID]

    #output the topology base to a file
    def outputTopo(self,filename):
        flag = False 
        f = open(filename,'a')        
        for (a,b,c,d) in self.topo:
            if (a!=-1 and b!=-1):
                if (flag==False):
                    f.write("TOPOLOGY\n")
                    flag = True
                msg1 = "router:{},router:{},linkid:{},cost:{}\n".format(a,b,c,d)
                msg2 = "router:{},router:{},linkid:{},cost:{}\n".format(b,a,c,d)
                f.write(msg1)
                f.write(msg2)
        f.write("\n")
        f.close()
        
        
#helper to format LSA messages 
def formatLSAMessage(msgtype, router_id, ID, RID, RLID, LC):
    LSA = struct.pack("!i",msgtype) #msgtype
    LSA += struct.pack("!i",router_id) #senderID
    LSA += struct.pack("!i",ID) #senderLinkID
    LSA += struct.pack("!i",RID)#RouterID
    LSA += struct.pack("!i",RLID) #RouterLinkID
    LSA += struct.pack("!i",LC)#RouterLinkCost
    return LSA

#output the routing table
def outputRouting(filename,g):
    flag = False
    msg = "Routing\n"
    dijkstra(g, g.get_vertex(router_id)) #run the dijkstra to determine shortest path
    for n in g:
        distance = g.get_vertex(n.id).get_distance()
        #print("n: {}, dist: {}".format(n.id, distance))
        if (n.id!=router_id and distance!=float("inf")):
            flag = True
           
            target = g.get_vertex(n.id)
            path = [target.get_id()]
            shortest(target, path)

            nextHop = path[len(path)-2]
            msg += "{}:{},{} \n".format(n.id,nextHop,distance)
            
            #print ("The shortest path : {}".format(path[::-1]))
            #print ("Vertex: {}, distance: {}".format(n.id,g.get_vertex(n.id).get_distance()))
            #print("The nexthop: {}".format(path[len(path)-2]))
                        
    #flag = False
    if (flag):       
        f = open(filename,'a')        
        f.write(msg+"\n")
        f.close()


        
#prcess parameters   
if (len(sys.argv)>3):
    string = sys.argv[1]
    nfe_ip = string
    #print("nfe_ip:"+nfe_ip)
    #get nfe_port
    string = sys.argv[2]
    if (string.isdigit()):
        nfe_port = int(string)
        #print("nfe_port:" + str(nfe_port))
    else:
        print ("Invalid nfe_port\n")
        #exit()
    #get router_id
    string = sys.argv[3]
    if (string.isdigit()):
        router_id = int(string)
        #print("router_id:" + str(router_id))
       # print(req_code)
    else:
        print ("Invalid router_id\n")
        #exit()

    #update filename and overwrite if it already exists 
    filename = "topology_{}.out".format(router_id)
    filename2 = "routingtable_{}.out".format(router_id)
    f = open(filename,'w')
    f.write("")
    f.close()
    f = open(filename2,'w')
    f.write("")
    f.close()
    
else:
    print ("Wrong number of parameters given\n")
    #exit()

'''
#forwarding phase
msgType = 3
senderID
senderLinkID
RouterID
RouterLinkID
RouterLinkCost '''


#UDP socket to send data
sock = socket(AF_INET, SOCK_DGRAM)
init = struct.pack("!i",1)
init += struct.pack("!i", router_id)
sock.sendto(init, (nfe_ip, nfe_port)) ##send init msg


m_topo = Topology() #my topology base 
m_graph = Graph()
m_graph.add_vertex(router_id)

#receive init-reply msg
buffer, address = sock.recvfrom(4096)
message_type_buffer = buffer[:4]
msg_type = struct.unpack("!i",message_type_buffer)[0]
if msg_type == 4:
    #print("received init_reply")
    numOfLinks_buffer = buffer[4:8]
    numOfLinks = struct.unpack("!i",numOfLinks_buffer)[0]
#print("numOflinks:" + str(numOfLinks))


s = 8
t = 12

links = [] #neighbouring links
c = 0
#process init-msg, add neighbour links to the topology
while numOfLinks!=c:
    linkId_buffer = buffer[s:t]
    linkId = struct.unpack("!i",linkId_buffer)[0]
    s += 4
    t += 4
    linkCost_buffer = buffer[s:t]
    linkCost = struct.unpack("!i",linkCost_buffer)[0]
    s += 4
    t += 4
    #print ("link id: " +str(linkId))
    #print("link cost:" + str(linkCost))
    #numOfLinks -= 1
    links.append([linkId, linkCost])

    m_topo.addEntry(router_id, -1, linkId, linkCost) #add entry to the topology, with the unknown router -1
    c+=1

#keep track of links that we already process [RID,RLID,LC]
linkInfo = []

 ##send LSA msg    
for (a,b) in links:
    for (ID, cost) in links:
        LSA = formatLSAMessage(3,router_id,a,router_id,ID,cost) #send all of the link information to link a
        sock.sendto(LSA, (nfe_ip, nfe_port)) ##send initial LSA msg
        print("Sending(E):SID({}),SLID({}),RID({}),RLID({}),LC({})".format(router_id,a,router_id,ID,cost))
        linkInfo.append([router_id,ID,cost]) #update linkInfo 


while (True):
    
    linkReceived = False  
    #receive LSA msg
    buffer, address = sock.recvfrom(4096)
    
    message_type_buffer = buffer[:4]
    msg_type = struct.unpack("!i",message_type_buffer)[0]
    
    if msg_type == 3:        
        SID_buffer = buffer[4:8]
        SID = struct.unpack("!i",SID_buffer)[0]
        SLID_buffer = buffer[8:12]
        SLID = struct.unpack("!i",SLID_buffer)[0]
        RID_buffer = buffer[12:16]
        RID = struct.unpack("!i",RID_buffer)[0]
        RLID_buffer = buffer[16:20]
        RLID = struct.unpack("!i",RLID_buffer)[0]
        LC_buffer = buffer[20:24]
        LC = struct.unpack("!i",LC_buffer)[0]     
        print("Received:SID({}),SLID({}),RID({}),RLID({}),LC({})".format(SID,SLID,RID,RLID,LC))

        #if [RID,RLID,LC] already seen, drop the LSA message (don't forward) 
        for [u,v,w] in linkInfo:
            if (u==RID and v==RLID and w==LC):
                linkReceived = True
                print("Dropping:SID({}),SLID({}),RID({}),RLID({}),LC({})".format(SID,SLID,RID,RLID,LC))
                break

        #if we haven't process this link, update topology and forward 
        if (linkReceived==False):
            linkInfo.append([RID,RLID,LC]) #update received links
            
            #update topo, if it doesn't exist, add to the topo with unknown router2=-1
            if (m_topo.findEntryByLID(RLID)==-1):
                m_topo.addEntry(RID,-1,RLID,LC)
            #if it already exist, update the unknown router2
            else:
                m_topo.updateRouter2(RLID, RID, m_graph)
            
            
                
            #forward the newly received link with new SID and SLID
            for (ID, cost) in links:
                if (ID!=SLID): #do not forward to the sender where it received from 
                    LSA = formatLSAMessage(3,router_id,ID,RID,RLID,LC) #change sender Id and sender link id 
                    print("Sending(F):SID({}),SLID({}),RID({}),RLID({}),LC({})".format(router_id,ID,RID,RLID,LC)) 
                    sock.sendto(LSA, (nfe_ip, nfe_port)) ##forward LSA msg

            #update topo and routing    
            m_topo.outputTopo(filename)
            outputRouting(filename2,m_graph)

